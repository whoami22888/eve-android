package com.eve.agent

import android.app.admin.DeviceAdminReceiver

class EveDeviceAdminReceiver : DeviceAdminReceiver()
