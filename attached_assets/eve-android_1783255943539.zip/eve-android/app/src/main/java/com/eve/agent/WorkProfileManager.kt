package com.eve.agent

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context

class WorkProfileManager(private val context: Context) {
    private val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    private val admin = ComponentName(context, EveDeviceAdminReceiver::class.java)

    fun createProfile(): Boolean {
        if (!dpm.isAdminActive(admin)) return false
        dpm.setProfileEnabled(admin, true)
        return true
    }
}
