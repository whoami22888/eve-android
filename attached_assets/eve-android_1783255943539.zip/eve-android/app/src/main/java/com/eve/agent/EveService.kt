package com.eve.agent

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

class EveService : Service() {
    private lateinit var python: Python
    private lateinit var eveModule: PyObject
    private lateinit var eveInstance: PyObject
    private lateinit var computer: VirtualComputer

    override fun onCreate() {
        super.onCreate()
        computer = VirtualComputer(this)
        startAccessibilityService()
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        python = Python.getInstance()
        eveModule = python.getModule("eve.orchestrator")
        eveInstance = eveModule.callAttr("EVE")
        val hermesCls = python.getModule("eve.hermes_agent").callAttr("HermesAgent")
        val hacxgentCls = python.getModule("eve.hacxgent_agent").callAttr("HacxgentAgent")
        val hermes = hermesCls()
        val hacxgent = hacxgentCls()
        eveInstance.callAttr("register_agent", "hermes", hermes)
        eveInstance.callAttr("register_agent", "hacxgent", hacxgent)
        eveInstance.callAttr("set_log_callback", PyObject { msg, level ->
            // Send to UI via broadcast
        })
        Thread { eveInstance.callAttr("run") }.start()
        startForeground(1, createNotification())
    }

    private fun createNotification(): Notification {
        val channelId = "eve_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "EVE Agent", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("EVE Agent")
            .setContentText("Orchestrating tasks")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
    }

    private fun startAccessibilityService() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onBind(intent: Intent?): IBinder = LocalBinder()
    inner class LocalBinder : Binder() { fun getService() = this@EveService }
}
