package com.eve.agent

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class MainActivity : AppCompatActivity() {
    private lateinit var viewPager: ViewPager2
    private lateinit var tabLayout: TabLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        viewPager = findViewById(R.id.viewPager)
        tabLayout = findViewById(R.id.tabLayout)
        val sections = listOf(
            "Dashboard" to DashboardFragment(),
            "Agent Computer" to AgentComputerFragment(),
            "Memory Editor" to MemoryEditorFragment(),
            "History" to HistoryFragment()
        )
        val adapter = SectionPagerAdapter(this, sections)
        viewPager.adapter = adapter
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = sections[position].first
        }.attach()
    }
}
