package com.eve.agent

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request

class GitHubSkillManager(private val context: Context) {
    private val client = OkHttpClient()

    fun listSkills(user: String, token: String): List<String> {
        val req = Request.Builder()
            .url("https://api.github.com/users/$user/repos")
            .addHeader("Authorization", "token $token")
            .build()
        val response = client.newCall(req).execute()
        val json = response.body?.string() ?: "[]"
        // parse...
        return listOf()
    }
}
