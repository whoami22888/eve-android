package com.eve.agent

import android.app.Service
import android.content.Intent
import android.os.IBinder

class SkillSandboxService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}
