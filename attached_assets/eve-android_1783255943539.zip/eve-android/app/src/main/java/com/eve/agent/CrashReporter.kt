package com.eve.agent

import android.content.Context
import java.io.File

class CrashReporter(context: Context) {
    private val logFile = File(context.filesDir, "crash.log")

    fun logError(error: String) {
        logFile.appendText("$error
")
    }
}
