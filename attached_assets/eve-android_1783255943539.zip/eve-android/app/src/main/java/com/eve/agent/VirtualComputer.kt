package com.eve.agent

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.*
import android.os.Build
import android.view.accessibility.AccessibilityNodeInfo
import okhttp3.*
import java.io.File
import java.util.concurrent.TimeUnit

class VirtualComputer(private val context: Context) {
    private var accessibilityService: VirtualAccessibilityService? = null
    private val okHttp = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    fun setAccessibilityService(service: VirtualAccessibilityService) {
        this.accessibilityService = service
    }

    fun captureScreen(): Bitmap? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            accessibilityService?.takeScreenshot()
        } else {
            // MediaProjection fallback (simplified)
            null
        }
    }

    fun moveMouse(x: Int, y: Int) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 1))
            .build()
        accessibilityService?.dispatchGesture(gesture, null, null)
    }

    fun click(x: Int? = null, y: Int? = null) {
        x?.let { moveMouse(it, y ?: return) }
        // Tap at current position – simplified
    }

    fun typeText(text: String) {
        val focused = accessibilityService?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        focused?.let { node ->
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }
    }

    fun executeScript(language: String, script: String, args: List<String> = emptyList()): String {
        return when (language.lowercase()) {
            "python" -> executePython(script, args)
            "shell", "sh", "bash" -> executeShell(script, args)
            else -> "Unsupported language: $language"
        }
    }

    private fun executePython(script: String, args: List<String>): String {
        return try {
            val py = Python.getInstance()
            val globals = py.getModule("builtins").callAttr("globals") as PyObject
            val result = py.callAttr("exec", script, globals)
            result.toString()
        } catch (e: Exception) {
            "Python error: ${e.message}"
        }
    }

    private fun executeShell(script: String, args: List<String>): String {
        return try {
            val process = ProcessBuilder("/system/bin/sh", "-c", script)
                .redirectErrorStream(true)
                .start()
            val output = process.inputStream.bufferedReader().readText()
            val exitCode = process.waitFor()
            if (exitCode == 0) output else "Shell error (exit $exitCode): $output"
        } catch (e: Exception) {
            "Shell error: ${e.message}"
        }
    }

    fun httpGet(url: String): String {
        val request = Request.Builder().url(url).build()
        okHttp.newCall(request).execute().use { response ->
            return response.body?.string() ?: ""
        }
    }
}
