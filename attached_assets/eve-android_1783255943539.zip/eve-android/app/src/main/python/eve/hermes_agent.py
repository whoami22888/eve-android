from flask import Flask, request, jsonify
import threading
from .task_queue import Task

class HermesAgent:
    def __init__(self):
        self.task_queue = None
        self.app = Flask(__name__)
        self.setup_routes()

    def setup_routes(self):
        @self.app.route('/command', methods=['POST'])
        def command():
            data = request.json
            action = data.get('action')
            params = data.get('params', {})
            task = Task(agent="hermes", action=action, params=params)
            self.task_queue.put(task)
            return jsonify({"status": "accepted", "task_id": task.id})

    def set_task_queue(self, q):
        self.task_queue = q

    def can_handle(self, task):
        return task.agent == "hermes"

    def assign_task(self, task):
        task.status = "completed"
        task.result = f"Processed {task.action}"

    def run(self):
        self.app.run(host='127.0.0.1', port=5000, threaded=True)
