import threading
import queue
import logging
from .task_queue import TaskQueue
from .hermes_agent import HermesAgent
from .hacxgent_agent import HacxgentAgent

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("EVE")

class EVE:
    def __init__(self):
        self.task_queue = TaskQueue()
        self.agents = {}
        self.running = False
        self.log_callback = None

    def register_agent(self, name, agent):
        self.agents[name] = agent
        agent.set_task_queue(self.task_queue)

    def set_log_callback(self, cb):
        self.log_callback = cb

    def log(self, msg, level="INFO"):
        if self.log_callback:
            self.log_callback(msg, level)
        else:
            logger.log(getattr(logging, level), msg)

    def run(self):
        self.running = True
        self.log("EVE started")
        for name, agent in self.agents.items():
            threading.Thread(target=agent.run, daemon=True).start()
            self.log(f"Agent {name} started")
        while self.running:
            try:
                task = self.task_queue.get(timeout=1)
                if not task: continue
                self.log(f"Received task: {task.id}")
                self.delegate(task)
            except queue.Empty:
                continue
            except Exception as e:
                self.log(f"Error: {e}", "ERROR")

    def delegate(self, task):
        for name, agent in self.agents.items():
            if agent.can_handle(task):
                agent.assign_task(task)
                self.log(f"Task {task.id} delegated to {name}")
                return
        self.log(f"No agent can handle task {task.id}", "ERROR")
