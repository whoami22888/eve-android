import queue
import uuid

class Task:
    def __init__(self, agent, action, params=None, task_id=None):
        self.id = task_id or uuid.uuid4().hex
        self.agent = agent
        self.action = action
        self.params = params or {}
        self.status = "pending"
        self.result = None

class TaskQueue:
    def __init__(self):
        self._queue = queue.Queue()
    def put(self, task):
        self._queue.put(task)
    def get(self, timeout=None):
        try:
            return self._queue.get(timeout=timeout)
        except queue.Empty:
            return None
