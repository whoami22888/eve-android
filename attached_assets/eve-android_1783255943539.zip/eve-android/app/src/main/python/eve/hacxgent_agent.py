from .task_queue import Task

class HacxgentAgent:
    def __init__(self):
        self.task_queue = None

    def set_task_queue(self, q):
        self.task_queue = q

    def can_handle(self, task):
        return task.agent == "hacxgent" or "scan" in task.action

    def assign_task(self, task):
        task.status = "completed"
        task.result = "Scan completed (simulated)"

    def run(self):
        pass
