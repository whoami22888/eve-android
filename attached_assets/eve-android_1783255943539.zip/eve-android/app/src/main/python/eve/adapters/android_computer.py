from java import jclass
VirtualComputer = jclass("com.eve.agent.VirtualComputer")
computer = VirtualComputer.getInstance()

def screenshot():
    return computer.captureScreen()

def moveTo(x, y):
    computer.moveMouse(x, y)

def click():
    computer.click()

def typewrite(text):
    computer.typeText(text)

def execute(language, script):
    return computer.executeScript(language, script)
