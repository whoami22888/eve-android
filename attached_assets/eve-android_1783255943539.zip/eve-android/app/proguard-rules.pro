# Keep Python classes
-keep class com.chaquo.python.** { *; }
-keep class com.eve.agent.** { *; }
